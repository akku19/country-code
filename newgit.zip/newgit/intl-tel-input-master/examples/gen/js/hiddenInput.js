var input = document.querySelector("#phone");
window.intlTelInput(input, {
  hiddenInput: "full_phone",
  utilsScript: "../../build/js/utils.js?1613236686837" // just for formatting/placeholders etc
});
